emoji = u'\U0001f433'
print emoji.encode('utf-8')