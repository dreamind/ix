#!python26/python.exe
'''
Return eval() in JSON or XML
'''
import cgi
import cgitb; cgitb.enable()
import math

data = cgi.FieldStorage()
expression = data.getfirst("field_input", "1+1") # default value is 1+1
via = data.getfirst("via", "json") # default value is json
try:
	result = str(eval(expression))
except:
	result = "Failed to evaluate expression"

if via == "json":
	# return json
	print 'Content-Type: text/plain\n'
	print '{'
	print '    "expression": "%s",' % (expression)
	print '    "result": "%s"' % (result)
	print '}' 
else:
	# return xml
	print 'Content-Type: text/xml\n'	
	print '<?xml version="1.0" encoding="utf-8"?>'
	print '<response>'
	print '    <expression><![CDATA[%s]]></expression>' % (expression)
	print '    <result>%s</result>' % (result)
	print '</response>'
