var thing = 'apple'

function f1() {
    console.log('in f1:', thing);
}

function f2() {
    thing = 'orange'; // this is exposed through closure
    console.log('in f2:', thing);
    
    function f2_1() {
        thing = 'banana'; // this is exposed through closure
        console.log('in f2_1:', thing);        
    }

    function f2_2() {
        var thing = 'pear'; // this is a local variable
        console.log('in f2_2:', thing);
    }

    f2_1();
    f2_2();
}
?