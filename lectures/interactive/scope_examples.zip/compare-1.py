thing = 'apple'

def f1():
    print 'in f1:', thing

def f2():
    thing = 'orange' # this is a local variable
    print 'in f2:', thing

def f3():
    global thing
    thing = 'banana' # this is a global variable
    print 'in f3:', thing
    
f1()
f2()
print thing
f3()
print thing
?