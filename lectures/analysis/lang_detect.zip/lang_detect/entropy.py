# -*- coding: utf-8 -*-
import nltk
from nltk.corpus import udhr
from collections import defaultdict
import math

def entropy(things):
    freqdist = nltk.FreqDist(things)
    probs = [freqdist.freq(l) for l in freqdist]
    return -sum(p * math.log(p,2) for p in probs)

def text_filter(text):
    for ch in " \n\t\r.,:;[]()\\/\"0123456789~!`?@#$%^&*_-=-":
        text = text.replace(ch, "")
    return text

languages = [
    "Italian-Latin1",
    "English-Latin1",
    "German_Deutsch-Latin1",
    "Spanish-Latin1", 
    "Chinese_Mandarin-UTF8",
    "Ukrainian-UTF8" ]

for lang in languages:
    udhr_text = text_filter(udhr.raw(lang).lower())
    print '%30s %2.5f %d %d' % (lang, entropy(udhr_text), len(udhr_text), len(udhr_text.encode('utf-32')))






