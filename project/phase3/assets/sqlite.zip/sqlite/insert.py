#!python26/python.exe
import sqlite3

# create/connect to a persistent file database
con = sqlite3.connect("mydb.db3")

# create the cursor needed to execute
cur = con.cursor()

insert_sql = """
INSERT INTO account VALUES ('A-101',  'Downtown', 500);
INSERT INTO account VALUES ('A-215',  'Mianus', 700);
INSERT INTO account VALUES ('A-102',  'Perryridge', 400);
INSERT INTO account VALUES ('A-305',  'Round Hill', 350);
INSERT INTO account VALUES ('A-201',  'Perryridge', 900);
INSERT INTO account VALUES ('A-333',  'Central',  850);
INSERT INTO account VALUES ('A-444',  'North Town', 625);
INSERT INTO account VALUES ('A-222',  'Redwood',  700);
INSERT INTO account VALUES ('A-217',  'Brighton', 750);
"""

# insert
for sql in insert_sql.split( ";" ):
    cur.execute( sql )
con.commit()

print "Content-Type: text/plain"
print
print "records are inserted"