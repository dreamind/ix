#!python26/python.exe
import sqlite3

# create/connect to a persistent file database
con = sqlite3.connect("mydb.db3")

# create the cursor needed to execute
cur = con.cursor()

# CREATE syntax: http://www.sqlite.org/lang_createtable.html
# supported data types: http://www.sqlite.org/datatype3.html

create_sql = """
CREATE TABLE IF NOT EXISTS account (
    account_number VARCHAR(15) NOT NULL UNIQUE,
    branch_name VARCHAR(15) NOT NULL,
    balance DECIMAL(12, 2) NOT NULL,
    PRIMARY KEY(account_number)
  )
"""

# create a table
cur.execute( create_sql )
con.commit()

print "Content-Type: text/plain"
print
print "account table is created"