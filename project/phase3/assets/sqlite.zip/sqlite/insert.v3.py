#!python26/python.exe
import sqlite3

# create/connect to a persistent file database
con = sqlite3.connect("mydb.db3")

# create the cursor needed to execute
cur = con.cursor()

unicode_text = u'\u6211\u7231\u4f60'
quotes_text = '\"Let\'s Go\"'

data = [
    ('C-001', unicode_text, 12.34),
    ('C-002', quotes_text, 56.78)
]

for row in data:
    cur.execute('INSERT INTO account VALUES (?,?,?)', row)

con.commit()

print "Content-Type: text/plain"
print
print "records are inserted"