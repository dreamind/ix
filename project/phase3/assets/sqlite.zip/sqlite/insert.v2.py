#!python26/python.exe
import sqlite3

# create/connect to a persistent file database
con = sqlite3.connect("mydb.db3")

# create the cursor needed to execute
cur = con.cursor()

data = [
    ('B-124', 'Carlton', 400),
    ('B-135', 'Brunswick',  500),
    ('B-227', 'Parkville', 600)
]

for row in data:
    cur.execute('INSERT INTO account VALUES (?,?,?)', row)

con.commit()

print "Content-Type: text/plain"
print
print "records are inserted"
