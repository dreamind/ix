#!python26/python.exe

''' Serve this page '''
import sqlite3

# create/connect to a persistent file database
con = sqlite3.connect("mydb.db3")

# create the cursor needed to execute
cur = con.cursor()

select_sql = """
SELECT * FROM account
"""

print "Content-Type: text/plain; charset=utf-8"
print

# create a table
cur.execute( select_sql )
for row in cur:
    for field in row:
        print unicode(field).encode('utf-8'), " ",
    print
