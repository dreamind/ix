#!/Users/dreamind/anaconda/bin/python
print "Content-Type: text/html\n"

print '''<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Server Side Demo</title>
</head>
<body>%s</body>
</html>''' % (3 * '<p>Hello World!</p>')
