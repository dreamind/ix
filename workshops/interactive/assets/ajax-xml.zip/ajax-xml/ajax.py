import math
import os
import json

from flask import Flask, request
app = Flask(__name__, static_folder='.', static_url_path='')

@app.route('/ajax-handler', methods=['POST'])
def handler():
  payload = request.data
  json_request = json.loads(payload)
  expression = json_request['expression'] or '1+1' # default expression is 1+1
  try:
    result = str(eval(expression))
  except:
    result = "Failed to evaluate expression"
  # return xml
  body = '<?xml version="1.0" encoding="utf-8"?>\n'
  body += '<response>\n'
  body += '    <expression><![CDATA[%s]]></expression>\n' % (expression)
  body += '    <result>%s</result>\n' % (result)
  body += '</response>\n'
  return body, 200, {'Content-Type': 'text/xml'}

if __name__ == "__main__":
    app.run(debug=True, host='127.0.0.1', port=8765)