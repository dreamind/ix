#!/Users/dreamind/anaconda/bin/python
import cgi
import cgitb; cgitb.enable()
import math

data = cgi.FieldStorage()
expression = data.getfirst("expression", "1+1") # default expression is 1+1
try:
	result = str(eval(expression))
except:
	result = "Failed to evaluate expression"

print 'Content-Type: text/xml\n'	
print '<?xml version="1.0" encoding="utf-8"?>'
print '<response>'
print '    <expression><![CDATA[%s]]></expression>' % (expression)
print '    <result>%s</result>' % (result)
print '</response>'

