#!/Users/dreamind/anaconda/bin/python
# -*- coding: utf-8 -*-
import cgi
import cgitb; cgitb.enable()
import re
import csv
import json

data = csv.DictReader(open('iris.csv'))
obj = map(lambda row: { key.strip(): float(value) if re.match(r"^[-+]?\d*\.?\d+([eE][-+]?\d+)?$", value) else value for key, value in row.iteritems() }, data)
print 'Content-Type: application/json'
print
print json.dumps(obj)